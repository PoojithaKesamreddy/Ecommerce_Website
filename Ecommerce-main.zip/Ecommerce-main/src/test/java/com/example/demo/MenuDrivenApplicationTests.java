package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MenuDrivenApplicationTests {  // Ensure this matches the main class name
    public static void main(String[] args) {
        SpringApplication.run(MenuDrivenApplicationTests.class, args);
    }
}
